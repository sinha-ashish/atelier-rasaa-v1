import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { IndiaMap, REGION_DATA } from '../components/IndiaMap';
import { ArrowRight, MapPin } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export const MapPage = () => {
  const { t, language } = useLanguage();
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [products, setProducts] = useState([]);
  const [materials, setMaterials] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();

  useEffect(() => {
    const region = searchParams.get('region');
    if (region) {
      setSelectedRegion(region);
      fetchByRegion(region);
    }
  }, [searchParams]);

  const fetchByRegion = async (regionId) => {
    if (!regionId) {
      setProducts([]);
      setMaterials([]);
      return;
    }

    setLoading(true);
    const regionName = REGION_DATA.find(r => r.id === regionId)?.name;
    
    try {
      const [productsRes, materialsRes] = await Promise.all([
        fetch(`${API}/products?region=${regionName}`),
        fetch(`${API}/materials?region=${regionName}`),
      ]);
      
      const productsData = await productsRes.json();
      const materialsData = await materialsRes.json();
      
      setProducts(productsData);
      setMaterials(materialsData);
    } catch (error) {
      console.error('Failed to fetch:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRegionSelect = (regionId) => {
    setSelectedRegion(regionId);
    const params = new URLSearchParams(searchParams);
    if (regionId) {
      params.set('region', regionId);
      fetchByRegion(regionId);
    } else {
      params.delete('region');
      setProducts([]);
      setMaterials([]);
    }
    setSearchParams(params);
  };

  const getRegionInfo = () => {
    if (!selectedRegion) return null;
    const region = REGION_DATA.find(r => r.id === selectedRegion);
    return region;
  };

  const regionInfo = getRegionInfo();
  const getName = (item) => language === 'fr' && item?.name_fr ? item.name_fr : item?.name;

  return (
    <div className="page-transition pt-24 min-h-screen" data-testid="map-page">
      {/* Header */}
      <section className="py-12 lg:py-20 px-6 lg:px-12 bg-champagne-light/30">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-overline text-burgundy mb-4">
            {language === 'en' ? 'Heritage over Haste' : 'L\'Héritage avant la Hâte'}
          </p>
          <h1 className="font-heading text-4xl lg:text-5xl tracking-tight text-text-primary mb-4">
            {t('map_title')}
          </h1>
          <p className="text-text-secondary max-w-2xl mx-auto">
            {t('map_subtitle')}
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Map */}
          <div>
            <IndiaMap 
              onRegionSelect={handleRegionSelect} 
              selectedRegion={selectedRegion} 
            />
          </div>

          {/* Region Info & Results */}
          <div>
            {!selectedRegion ? (
              <div className="text-center py-12">
                <MapPin className="w-12 h-12 text-champagne mx-auto mb-4" />
                <p className="text-text-secondary">
                  {language === 'en' 
                    ? 'Select a region on the map to explore its artisan traditions'
                    : 'Sélectionnez une région sur la carte pour explorer ses traditions artisanales'}
                </p>
              </div>
            ) : (
              <div>
                {/* Region Header */}
                <div className="mb-8 pb-8 border-b border-champagne">
                  <h2 className="font-heading text-3xl tracking-tight text-text-primary mb-2">
                    {language === 'fr' ? regionInfo?.nameFr : regionInfo?.name}
                  </h2>
                  <div className="flex flex-wrap gap-2">
                    {regionInfo?.crafts.map((craft, i) => (
                      <span key={i} className="text-xs bg-burgundy/10 text-burgundy px-3 py-1 rounded-full">
                        {craft}
                      </span>
                    ))}
                  </div>
                </div>

                {loading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="animate-pulse flex gap-4">
                        <div className="w-20 h-20 bg-champagne/30" />
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-champagne/30 w-3/4" />
                          <div className="h-3 bg-champagne/30 w-1/2" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <>
                    {/* B2C Products */}
                    {products.length > 0 && (
                      <div className="mb-8">
                        <h3 className="text-overline text-emerald mb-4">
                          {language === 'en' ? 'From The Edit' : 'De La Sélection'}
                        </h3>
                        <div className="space-y-4">
                          {products.slice(0, 3).map((product) => (
                            <Link
                              key={product.id}
                              to={`/product/${product.id}`}
                              className="flex gap-4 group"
                              data-testid={`map-product-${product.id}`}
                            >
                              <img
                                src={product.image}
                                alt={getName(product)}
                                className="w-20 h-20 object-cover flex-shrink-0"
                              />
                              <div className="flex-1 min-w-0">
                                <h4 className="font-heading text-lg text-text-primary group-hover:text-burgundy transition-colors truncate">
                                  {getName(product)}
                                </h4>
                                <p className="text-sm text-text-secondary">{product.artisan_cluster}</p>
                                <p className="text-burgundy font-medium">€{product.price.toLocaleString()}</p>
                              </div>
                            </Link>
                          ))}
                        </div>
                        <Link
                          to={`/boutique?region=${selectedRegion}`}
                          className="inline-flex items-center gap-2 text-sm text-burgundy hover:underline mt-4"
                        >
                          {language === 'en' ? 'View all products' : 'Voir tous les produits'}
                          <ArrowRight className="w-4 h-4" />
                        </Link>
                      </div>
                    )}

                    {/* B2B Materials */}
                    {materials.length > 0 && (
                      <div>
                        <h3 className="text-overline text-emerald mb-4">
                          {language === 'en' ? 'B2B Materials' : 'Matériaux B2B'}
                        </h3>
                        <div className="space-y-4">
                          {materials.slice(0, 3).map((material) => (
                            <div
                              key={material.id}
                              className="flex gap-4"
                              data-testid={`map-material-${material.id}`}
                            >
                              <img
                                src={material.image}
                                alt={getName(material)}
                                className="w-20 h-20 object-cover flex-shrink-0"
                              />
                              <div className="flex-1 min-w-0">
                                <h4 className="font-heading text-lg text-text-primary truncate">
                                  {getName(material)}
                                </h4>
                                <p className="text-sm text-text-secondary">{material.subcategory}</p>
                                <p className="text-xs text-emerald">{material.price_range}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                        <Link
                          to={`/showroom?region=${selectedRegion}`}
                          className="inline-flex items-center gap-2 text-sm text-burgundy hover:underline mt-4"
                        >
                          {language === 'en' ? 'View in Showroom' : 'Voir dans le Showroom'}
                          <ArrowRight className="w-4 h-4" />
                        </Link>
                      </div>
                    )}

                    {products.length === 0 && materials.length === 0 && (
                      <p className="text-text-secondary text-center py-8">
                        {language === 'en' 
                          ? 'No items currently available from this region.'
                          : 'Aucun article actuellement disponible de cette région.'}
                      </p>
                    )}
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
