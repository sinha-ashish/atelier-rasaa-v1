import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Hero } from '../components/Hero';
import { ArrowRight, Gem, Shirt, Compass, MapPin } from 'lucide-react';

const FEATURED_CATEGORIES = [
  {
    id: 'jewelry',
    icon: Gem,
    image: 'https://images.pexels.com/photos/1395306/pexels-photo-1395306.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
  },
  {
    id: 'apparel',
    icon: Shirt,
    image: 'https://images.pexels.com/photos/1066171/pexels-photo-1066171.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
  },
  {
    id: 'carpets',
    icon: Compass,
    image: 'https://images.pexels.com/photos/6786956/pexels-photo-6786956.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
  },
];

const CRAFT_REGIONS = [
  { name: 'Jaipur', craft: 'Kundan Jewelry' },
  { name: 'Varanasi', craft: 'Banarasi Silk' },
  { name: 'Kashmir', craft: 'Pashmina & Carpets' },
  { name: 'Chanderi', craft: 'Silk Weaving' },
];

export const HomePage = () => {
  const { t, language } = useLanguage();

  const categoryLabels = {
    jewelry: t('cat_jewelry'),
    apparel: t('cat_apparel'),
    carpets: t('cat_carpets'),
  };

  return (
    <div className="page-transition" data-testid="home-page">
      {/* Hero Section */}
      <Hero />

      {/* Categories Section */}
      <section className="py-20 lg:py-32 px-6 lg:px-12 bg-museum-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-overline text-burgundy mb-4">{t('nav_boutique')}</p>
            <h2 className="font-heading text-3xl lg:text-4xl tracking-tight text-text-primary">
              {language === 'en' ? 'Curated Collections' : 'Collections Sélectionnées'}
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
            {FEATURED_CATEGORIES.map((cat) => (
              <Link
                key={cat.id}
                to={`/boutique?category=${cat.id}`}
                className="group product-card relative overflow-hidden aspect-[3/4]"
                data-testid={`category-card-${cat.id}`}
              >
                <img
                  src={cat.image}
                  alt={categoryLabels[cat.id]}
                  className="product-image absolute inset-0 w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
                  <h3 className="font-heading text-2xl lg:text-3xl text-white mb-2">
                    {categoryLabels[cat.id]}
                  </h3>
                  <span className="inline-flex items-center gap-2 text-champagne text-sm uppercase tracking-wider group-hover:gap-3 transition-all">
                    {language === 'en' ? 'Explore' : 'Découvrir'}
                    <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Craft Regions Preview */}
      <section className="py-20 lg:py-32 px-6 lg:px-12 bg-champagne-light/30">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <p className="text-overline text-emerald mb-4">
                {language === 'en' ? 'Heritage over Haste' : 'L\'Héritage avant la Hâte'}
              </p>
              <h2 className="font-heading text-3xl lg:text-4xl tracking-tight text-text-primary mb-6">
                {t('map_title')}
              </h2>
              <p className="text-text-secondary leading-relaxed mb-8">
                {language === 'en' 
                  ? 'Each piece in our collection traces back to a specific artisan cluster in India. Discover the stories, techniques, and heritage behind every creation.'
                  : 'Chaque pièce de notre collection remonte à un groupe d\'artisans spécifique en Inde. Découvrez les histoires, techniques et le patrimoine derrière chaque création.'}
              </p>
              
              <div className="grid grid-cols-2 gap-4 mb-8">
                {CRAFT_REGIONS.map((region) => (
                  <div key={region.name} className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-burgundy mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-text-primary">{region.name}</p>
                      <p className="text-sm text-text-secondary">{region.craft}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Link
                to="/map"
                className="btn-luxury inline-flex items-center gap-2"
                data-testid="explore-map-btn"
              >
                {language === 'en' ? 'Explore Heritage Map' : 'Explorer la Carte'}
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1773842298512-e49c9331cc3d?auto=format&fit=crop&q=80"
                alt="Artisan weaving"
                className="w-full aspect-[4/5] object-cover"
              />
              <div className="absolute -bottom-6 -left-6 bg-burgundy text-white p-6 max-w-xs">
                <p className="text-overline text-champagne mb-2">
                  {language === 'en' ? 'Artisan Story' : 'Histoire d\'Artisan'}
                </p>
                <p className="text-sm leading-relaxed">
                  {language === 'en' 
                    ? '"Three generations of our family have woven these patterns. Each thread carries our legacy."'
                    : '"Trois générations de notre famille ont tissé ces motifs. Chaque fil porte notre héritage."'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* B2B Teaser */}
      <section className="py-20 lg:py-32 px-6 lg:px-12 bg-emerald text-white">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-overline text-champagne mb-4">
            {language === 'en' ? 'For Professional Partners' : 'Pour Partenaires Professionnels'}
          </p>
          <h2 className="font-heading text-3xl lg:text-5xl tracking-tight mb-6">
            {t('b2b_title')}
          </h2>
          <p className="text-white/80 max-w-2xl mx-auto mb-10 leading-relaxed">
            {t('b2b_subtitle')}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/showroom"
              className="btn-luxury text-white border-white/50 hover:bg-white hover:text-emerald"
              data-testid="b2b-cta-btn"
            >
              {t('b2b_request_access')}
            </Link>
          </div>
        </div>
      </section>

      {/* DDP Notice */}
      <section className="py-8 px-6 bg-champagne/30 border-y border-champagne">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-text-secondary">
            {t('ddp_notice')}
          </p>
        </div>
      </section>
    </div>
  );
};
