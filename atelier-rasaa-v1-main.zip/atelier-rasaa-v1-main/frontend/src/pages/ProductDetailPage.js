import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Button } from '../components/ui/button';
import { MapPin, ArrowLeft, Check } from 'lucide-react';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export const ProductDetailPage = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [contactOpen, setContactOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const { t, language } = useLanguage();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  useEffect(() => {
    fetchProduct();
  }, [id]);

  const fetchProduct = async () => {
    try {
      const response = await fetch(`${API}/products/${id}`);
      if (response.ok) {
        const data = await response.json();
        setProduct(data);
      }
    } catch (error) {
      console.error('Failed to fetch product:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitContact = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const response = await fetch(`${API}/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          subject: `Inquiry about ${product?.name}`,
          product_id: id,
        }),
      });
      if (response.ok) {
        toast.success(t('contact_success'));
        setContactOpen(false);
        setFormData({ name: '', email: '', subject: '', message: '' });
      }
    } catch (error) {
      toast.error('Failed to send message');
    } finally {
      setSubmitting(false);
    }
  };

  const getName = (p) => language === 'fr' && p?.name_fr ? p.name_fr : p?.name;
  const getDesc = (p) => language === 'fr' && p?.description_fr ? p.description_fr : p?.description;
  const getProvenance = (p) => language === 'fr' && p?.provenance_fr ? p.provenance_fr : p?.provenance;

  if (loading) {
    return (
      <div className="pt-24 min-h-screen">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
          <div className="animate-pulse grid lg:grid-cols-2 gap-12">
            <div className="aspect-square bg-champagne/30" />
            <div className="space-y-4">
              <div className="h-8 bg-champagne/30 w-1/2" />
              <div className="h-6 bg-champagne/30 w-1/3" />
              <div className="h-24 bg-champagne/30" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="pt-24 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-heading text-2xl mb-4">Product not found</h1>
          <Link to="/boutique" className="btn-luxury">
            {language === 'en' ? 'Back to Shop' : 'Retour à la Boutique'}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="page-transition pt-24 min-h-screen" data-testid="product-detail-page">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
        {/* Breadcrumb */}
        <Link 
          to="/boutique" 
          className="inline-flex items-center gap-2 text-text-secondary hover:text-burgundy mb-8 text-sm"
          data-testid="back-to-boutique"
        >
          <ArrowLeft className="w-4 h-4" />
          {language === 'en' ? 'Back to The Edit' : 'Retour à La Sélection'}
        </Link>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Product Image */}
          <div className="relative">
            <img
              src={product.image}
              alt={getName(product)}
              className="w-full aspect-square object-cover"
              data-testid="product-main-image"
            />
          </div>

          {/* Product Info */}
          <div>
            <div className="flex items-center gap-2 text-emerald text-sm mb-4">
              <MapPin className="w-4 h-4" />
              <span>{product.region} • {product.artisan_cluster}</span>
            </div>

            <h1 className="font-heading text-3xl lg:text-4xl tracking-tight text-text-primary mb-4" data-testid="product-title">
              {getName(product)}
            </h1>

            <p className="text-2xl text-burgundy font-medium mb-6" data-testid="product-price">
              €{product.price.toLocaleString()}
              <span className="text-sm text-text-secondary ml-2">DDP France</span>
            </p>

            <p className="text-text-secondary leading-relaxed mb-8" data-testid="product-description">
              {getDesc(product)}
            </p>

            {/* CTA */}
            <Dialog open={contactOpen} onOpenChange={setContactOpen}>
              <DialogTrigger asChild>
                <button className="btn-luxury btn-luxury-filled w-full mb-8" data-testid="inquire-btn">
                  {t('product_contact_cta')}
                </button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="font-heading text-xl">{t('contact_title')}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmitContact} className="space-y-4 mt-4">
                  <Input
                    placeholder={t('contact_name')}
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    data-testid="contact-name-input"
                  />
                  <Input
                    type="email"
                    placeholder={t('contact_email')}
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    data-testid="contact-email-input"
                  />
                  <Textarea
                    placeholder={t('contact_message')}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={4}
                    required
                    data-testid="contact-message-input"
                  />
                  <Button 
                    type="submit" 
                    disabled={submitting}
                    className="w-full bg-burgundy hover:bg-burgundy-hover text-white"
                    data-testid="contact-submit-btn"
                  >
                    {submitting ? '...' : t('contact_send')}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>

            {/* Provenance Section */}
            <div className="border-t border-champagne pt-8" data-testid="provenance-section">
              <h3 className="text-overline text-burgundy mb-4">{t('product_provenance')}</h3>
              <div className="bg-champagne-light/50 p-6">
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full bg-burgundy flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-text-primary">{product.artisan_cluster}</p>
                    <p className="text-sm text-text-secondary">{product.region}, India</p>
                  </div>
                </div>
                <p className="text-text-secondary leading-relaxed italic">
                  "{getProvenance(product)}"
                </p>
              </div>
            </div>

            {/* Features */}
            <div className="mt-8 space-y-3">
              {[
                language === 'en' ? 'Authenticity Certificate Included' : 'Certificat d\'Authenticité Inclus',
                language === 'en' ? 'Direct from Artisan' : 'Direct de l\'Artisan',
                language === 'en' ? 'DDP Shipping to France' : 'Livraison DDP vers la France',
              ].map((feature, i) => (
                <div key={i} className="flex items-center gap-3 text-sm text-text-secondary">
                  <Check className="w-4 h-4 text-emerald" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
