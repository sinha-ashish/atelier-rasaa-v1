import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { IndiaMap, REGION_DATA } from '../components/IndiaMap';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Lock, FileDown, MessageSquare, MapPin, Gem, Scissors } from 'lucide-react';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export const ShowroomPage = () => {
  const { isAuthenticated, user } = useAuth();
  const { t, language } = useLanguage();
  const [materials, setMaterials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('gemstones');
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [wholesaleOpen, setWholesaleOpen] = useState(false);
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [selectedMaterial, setSelectedMaterial] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();

  const isB2BUser = isAuthenticated && user?.is_b2b && user?.is_approved;

  const [wholesaleForm, setWholesaleForm] = useState({
    company_name: '',
    contact_name: '',
    email: '',
    phone: '',
    business_type: '',
    message: '',
  });

  const [quoteForm, setQuoteForm] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    quantity: '',
    specifications: '',
  });

  useEffect(() => {
    const region = searchParams.get('region');
    if (region) setSelectedRegion(region);
  }, [searchParams]);

  useEffect(() => {
    fetchMaterials();
  }, [selectedCategory, selectedRegion]);

  const fetchMaterials = async () => {
    setLoading(true);
    try {
      let url = `${API}/materials?category=${selectedCategory}`;
      if (selectedRegion) {
        const regionName = REGION_DATA.find(r => r.id === selectedRegion)?.name;
        if (regionName) url += `&region=${regionName}`;
      }
      
      const response = await fetch(url);
      const data = await response.json();
      setMaterials(data);
    } catch (error) {
      console.error('Failed to fetch materials:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRegionFilter = (region) => {
    setSelectedRegion(region);
    const params = new URLSearchParams(searchParams);
    if (region) {
      params.set('region', region);
    } else {
      params.delete('region');
    }
    setSearchParams(params);
  };

  const handleWholesaleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const response = await fetch(`${API}/wholesale/request`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(wholesaleForm),
      });
      if (response.ok) {
        toast.success(t('wholesale_success'));
        setWholesaleOpen(false);
        setWholesaleForm({
          company_name: '', contact_name: '', email: '',
          phone: '', business_type: '', message: '',
        });
      }
    } catch (error) {
      toast.error('Failed to submit request');
    } finally {
      setSubmitting(false);
    }
  };

  const handleQuoteSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const response = await fetch(`${API}/quote/request`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          material_id: selectedMaterial?.id,
          material_name: selectedMaterial?.name,
          ...quoteForm,
        }),
      });
      if (response.ok) {
        toast.success(t('quote_success'));
        setQuoteOpen(false);
        setQuoteForm({
          name: '', email: '', company: '',
          phone: '', quantity: '', specifications: '',
        });
      }
    } catch (error) {
      toast.error('Failed to submit quote request');
    } finally {
      setSubmitting(false);
    }
  };

  const openQuoteDialog = (material) => {
    setSelectedMaterial(material);
    setQuoteOpen(true);
  };

  const getName = (m) => language === 'fr' && m?.name_fr ? m.name_fr : m?.name;
  const getDesc = (m) => language === 'fr' && m?.description_fr ? m.description_fr : m?.description;

  return (
    <div className="page-transition pt-24 min-h-screen" data-testid="showroom-page">
      {/* Header */}
      <section className="py-12 lg:py-20 px-6 lg:px-12 bg-emerald text-white">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-overline text-champagne mb-4">
            {language === 'en' ? 'B2B Sourcing' : 'Sourcing B2B'}
          </p>
          <h1 className="font-heading text-4xl lg:text-5xl tracking-tight mb-4">
            {t('b2b_title')}
          </h1>
          <p className="text-white/80 max-w-2xl mx-auto">
            {t('b2b_subtitle')}
          </p>
        </div>
      </section>

      {/* Access Gate or Content */}
      {!isB2BUser ? (
        <section className="py-20 lg:py-32 px-6 lg:px-12 bg-museum-white">
          <div className="max-w-2xl mx-auto text-center">
            <div className="w-20 h-20 rounded-full bg-champagne/50 flex items-center justify-center mx-auto mb-8">
              <Lock className="w-8 h-8 text-burgundy" />
            </div>
            <h2 className="font-heading text-2xl lg:text-3xl tracking-tight text-text-primary mb-4">
              {t('b2b_access_title')}
            </h2>
            <p className="text-text-secondary mb-8 leading-relaxed">
              {t('b2b_access_desc')}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {/* Wholesale Access Request Dialog */}
              <Dialog open={wholesaleOpen} onOpenChange={setWholesaleOpen}>
                <DialogTrigger asChild>
                  <button className="btn-luxury btn-luxury-filled" data-testid="request-access-btn">
                    {t('b2b_request_access')}
                  </button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="font-heading text-xl">{t('wholesale_title')}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleWholesaleSubmit} className="space-y-4 mt-4">
                    <Input
                      placeholder={t('wholesale_company')}
                      value={wholesaleForm.company_name}
                      onChange={(e) => setWholesaleForm({ ...wholesaleForm, company_name: e.target.value })}
                      required
                      data-testid="wholesale-company-input"
                    />
                    <Input
                      placeholder={t('wholesale_contact')}
                      value={wholesaleForm.contact_name}
                      onChange={(e) => setWholesaleForm({ ...wholesaleForm, contact_name: e.target.value })}
                      required
                      data-testid="wholesale-contact-input"
                    />
                    <Input
                      type="email"
                      placeholder={t('auth_email')}
                      value={wholesaleForm.email}
                      onChange={(e) => setWholesaleForm({ ...wholesaleForm, email: e.target.value })}
                      required
                      data-testid="wholesale-email-input"
                    />
                    <Input
                      placeholder={t('wholesale_phone')}
                      value={wholesaleForm.phone}
                      onChange={(e) => setWholesaleForm({ ...wholesaleForm, phone: e.target.value })}
                      required
                      data-testid="wholesale-phone-input"
                    />
                    <Select
                      value={wholesaleForm.business_type}
                      onValueChange={(value) => setWholesaleForm({ ...wholesaleForm, business_type: value })}
                    >
                      <SelectTrigger data-testid="wholesale-business-select">
                        <SelectValue placeholder={t('wholesale_business')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fashion_house">{language === 'en' ? 'Fashion House' : 'Maison de Mode'}</SelectItem>
                        <SelectItem value="jewelry_brand">{language === 'en' ? 'Jewelry Brand' : 'Marque de Bijoux'}</SelectItem>
                        <SelectItem value="interior_design">{language === 'en' ? 'Interior Design' : 'Design d\'Intérieur'}</SelectItem>
                        <SelectItem value="retailer">{language === 'en' ? 'Retailer' : 'Détaillant'}</SelectItem>
                        <SelectItem value="other">{language === 'en' ? 'Other' : 'Autre'}</SelectItem>
                      </SelectContent>
                    </Select>
                    <Textarea
                      placeholder={t('wholesale_message')}
                      value={wholesaleForm.message}
                      onChange={(e) => setWholesaleForm({ ...wholesaleForm, message: e.target.value })}
                      rows={3}
                      data-testid="wholesale-message-input"
                    />
                    <Button 
                      type="submit" 
                      disabled={submitting}
                      className="w-full bg-burgundy hover:bg-burgundy-hover text-white"
                      data-testid="wholesale-submit-btn"
                    >
                      {submitting ? '...' : t('wholesale_submit')}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>

              <Link to="/login" className="btn-luxury" data-testid="partner-login-btn">
                {t('b2b_login')}
              </Link>
            </div>

            {/* Preview Grid */}
            <div className="mt-16">
              <p className="text-overline text-text-secondary mb-6">
                {language === 'en' ? 'Preview Our Collections' : 'Aperçu de Nos Collections'}
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { icon: Gem, label: language === 'en' ? 'Jaipur Stones' : 'Pierres de Jaipur' },
                  { icon: Gem, label: language === 'en' ? 'Lab Diamonds' : 'Diamants Labo' },
                  { icon: Scissors, label: language === 'en' ? 'Block Prints' : 'Impressions Bloc' },
                  { icon: Scissors, label: language === 'en' ? 'Silks' : 'Soies' },
                ].map((item, i) => (
                  <div key={i} className="p-6 bg-champagne/20 border border-champagne/30 text-center">
                    <item.icon className="w-8 h-8 text-burgundy mx-auto mb-3" strokeWidth={1.5} />
                    <p className="text-sm text-text-primary">{item.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      ) : (
        /* Authenticated B2B Content */
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <aside className="lg:col-span-1">
              {/* Category Tabs */}
              <div className="mb-8">
                <h3 className="text-overline text-text-secondary mb-4">
                  {language === 'en' ? 'Material Library' : 'Bibliothèque de Matériaux'}
                </h3>
                <div className="space-y-2">
                  <button
                    onClick={() => setSelectedCategory('gemstones')}
                    className={`block w-full text-left px-4 py-3 text-sm transition-colors ${
                      selectedCategory === 'gemstones'
                        ? 'bg-burgundy text-white'
                        : 'bg-champagne/30 text-text-primary hover:bg-champagne/50'
                    }`}
                    data-testid="filter-gemstones"
                  >
                    <Gem className="w-4 h-4 inline mr-2" />
                    {t('cat_gemstones')}
                  </button>
                  <button
                    onClick={() => setSelectedCategory('textiles')}
                    className={`block w-full text-left px-4 py-3 text-sm transition-colors ${
                      selectedCategory === 'textiles'
                        ? 'bg-burgundy text-white'
                        : 'bg-champagne/30 text-text-primary hover:bg-champagne/50'
                    }`}
                    data-testid="filter-textiles"
                  >
                    <Scissors className="w-4 h-4 inline mr-2" />
                    {t('cat_textiles')}
                  </button>
                </div>
              </div>

              {/* Region Filter */}
              <div>
                <h3 className="text-overline text-text-secondary mb-4">
                  {language === 'en' ? 'Filter by Region' : 'Filtrer par Région'}
                </h3>
                <IndiaMap 
                  onRegionSelect={handleRegionFilter} 
                  selectedRegion={selectedRegion} 
                />
              </div>
            </aside>

            {/* Materials Grid */}
            <main className="lg:col-span-3">
              {loading ? (
                <div className="grid md:grid-cols-2 gap-6">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="animate-pulse border border-champagne/30 p-4">
                      <div className="aspect-video bg-champagne/30 mb-4" />
                      <div className="h-5 bg-champagne/30 w-3/4 mb-2" />
                      <div className="h-4 bg-champagne/30 w-1/2" />
                    </div>
                  ))}
                </div>
              ) : materials.length === 0 ? (
                <div className="text-center py-16">
                  <p className="text-text-secondary">
                    {language === 'en' ? 'No materials found.' : 'Aucun matériau trouvé.'}
                  </p>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-6">
                  {materials.map((material) => (
                    <div
                      key={material.id}
                      className="border border-champagne/30 bg-white"
                      data-testid={`material-card-${material.id}`}
                    >
                      <div className="relative aspect-video">
                        <img
                          src={material.image}
                          alt={getName(material)}
                          className="absolute inset-0 w-full h-full object-cover"
                        />
                      </div>
                      <div className="p-4">
                        <div className="flex items-center gap-1 text-xs text-emerald mb-1">
                          <MapPin className="w-3 h-3" />
                          <span>{material.region}</span>
                        </div>
                        <h3 className="font-heading text-lg text-text-primary mb-1">
                          {getName(material)}
                        </h3>
                        <p className="text-sm text-text-secondary mb-3 line-clamp-2">
                          {getDesc(material)}
                        </p>

                        {/* B2B Details */}
                        <div className="grid grid-cols-3 gap-2 text-xs text-text-secondary mb-4 border-t border-champagne/30 pt-3">
                          <div>
                            <span className="block text-text-primary font-medium">{material.price_range}</span>
                            <span>{language === 'en' ? 'Price' : 'Prix'}</span>
                          </div>
                          <div>
                            <span className="block text-text-primary font-medium">{material.min_order}</span>
                            <span>{language === 'en' ? 'MOQ' : 'QMC'}</span>
                          </div>
                          <div>
                            <span className="block text-text-primary font-medium">{material.lead_time}</span>
                            <span>{language === 'en' ? 'Lead' : 'Délai'}</span>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-2">
                          <button
                            onClick={() => openQuoteDialog(material)}
                            className="flex-1 btn-luxury text-xs py-2 flex items-center justify-center gap-1"
                            data-testid={`quote-btn-${material.id}`}
                          >
                            <MessageSquare className="w-3 h-3" />
                            {t('product_quote_cta')}
                          </button>
                          <button
                            className="btn-luxury text-xs py-2 px-3"
                            title={language === 'en' ? 'Download Certificate' : 'Télécharger Certificat'}
                            data-testid={`cert-btn-${material.id}`}
                          >
                            <FileDown className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </main>
          </div>

          {/* Quote Dialog */}
          <Dialog open={quoteOpen} onOpenChange={setQuoteOpen}>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="font-heading text-xl">
                  {t('quote_title')}
                  {selectedMaterial && (
                    <span className="block text-sm font-body text-text-secondary mt-1">
                      {getName(selectedMaterial)}
                    </span>
                  )}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleQuoteSubmit} className="space-y-4 mt-4">
                <Input
                  placeholder={t('contact_name')}
                  value={quoteForm.name}
                  onChange={(e) => setQuoteForm({ ...quoteForm, name: e.target.value })}
                  required
                  data-testid="quote-name-input"
                />
                <Input
                  type="email"
                  placeholder={t('contact_email')}
                  value={quoteForm.email}
                  onChange={(e) => setQuoteForm({ ...quoteForm, email: e.target.value })}
                  required
                  data-testid="quote-email-input"
                />
                <Input
                  placeholder={t('auth_company')}
                  value={quoteForm.company}
                  onChange={(e) => setQuoteForm({ ...quoteForm, company: e.target.value })}
                  data-testid="quote-company-input"
                />
                <Input
                  placeholder={t('quote_quantity')}
                  value={quoteForm.quantity}
                  onChange={(e) => setQuoteForm({ ...quoteForm, quantity: e.target.value })}
                  required
                  data-testid="quote-quantity-input"
                />
                <Textarea
                  placeholder={t('quote_specs')}
                  value={quoteForm.specifications}
                  onChange={(e) => setQuoteForm({ ...quoteForm, specifications: e.target.value })}
                  rows={3}
                  data-testid="quote-specs-input"
                />
                <Button 
                  type="submit" 
                  disabled={submitting}
                  className="w-full bg-burgundy hover:bg-burgundy-hover text-white"
                  data-testid="quote-submit-btn"
                >
                  {submitting ? '...' : t('quote_submit')}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      )}
    </div>
  );
};
