import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { IndiaMap, REGION_DATA } from '../components/IndiaMap';
import { MapPin, ArrowRight } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const CATEGORY_IMAGES = {
  jewelry: 'https://images.pexels.com/photos/1395306/pexels-photo-1395306.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
  apparel: 'https://images.pexels.com/photos/1066171/pexels-photo-1066171.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
  carpets: 'https://images.pexels.com/photos/6786956/pexels-photo-6786956.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
};

export const BoutiquePage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedRegion, setSelectedRegion] = useState(null);
  const { t, language } = useLanguage();
  const [searchParams, setSearchParams] = useSearchParams();

  useEffect(() => {
    const cat = searchParams.get('category');
    const region = searchParams.get('region');
    if (cat) setSelectedCategory(cat);
    if (region) setSelectedRegion(region);
  }, [searchParams]);

  useEffect(() => {
    fetchProducts();
  }, [selectedCategory, selectedRegion]);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      let url = `${API}/products`;
      const params = new URLSearchParams();
      if (selectedCategory) params.append('category', selectedCategory);
      if (selectedRegion) {
        const regionName = REGION_DATA.find(r => r.id === selectedRegion)?.name;
        if (regionName) params.append('region', regionName);
      }
      if (params.toString()) url += `?${params.toString()}`;
      
      const response = await fetch(url);
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error('Failed to fetch products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCategoryFilter = (cat) => {
    setSelectedCategory(cat === selectedCategory ? null : cat);
    const params = new URLSearchParams(searchParams);
    if (cat === selectedCategory) {
      params.delete('category');
    } else {
      params.set('category', cat);
    }
    setSearchParams(params);
  };

  const handleRegionFilter = (region) => {
    setSelectedRegion(region);
    const params = new URLSearchParams(searchParams);
    if (region) {
      params.set('region', region);
    } else {
      params.delete('region');
    }
    setSearchParams(params);
  };

  const getName = (product) => language === 'fr' && product.name_fr ? product.name_fr : product.name;

  const categories = [
    { id: 'jewelry', label: t('cat_jewelry') },
    { id: 'apparel', label: t('cat_apparel') },
    { id: 'carpets', label: t('cat_carpets') },
  ];

  return (
    <div className="page-transition pt-24" data-testid="boutique-page">
      {/* Header */}
      <section className="py-12 lg:py-20 px-6 lg:px-12 bg-champagne-light/30">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-overline text-burgundy mb-4">
            {language === 'en' ? 'B2C Atelier Boutique' : 'Boutique Atelier B2C'}
          </p>
          <h1 className="font-heading text-4xl lg:text-5xl tracking-tight text-text-primary mb-4">
            {t('nav_boutique')}
          </h1>
          <p className="text-text-secondary max-w-2xl mx-auto">
            {language === 'en' 
              ? 'A curated selection of jewelry, apparel, and hand-knotted carpets from Pan-India homegrown brands.'
              : 'Une sélection de bijoux, vêtements et tapis noués main de marques indiennes artisanales.'}
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar Filters */}
          <aside className="lg:col-span-1">
            {/* Category Filter */}
            <div className="mb-8">
              <h3 className="text-overline text-text-secondary mb-4">
                {language === 'en' ? 'Categories' : 'Catégories'}
              </h3>
              <div className="space-y-2">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => handleCategoryFilter(cat.id)}
                    className={`block w-full text-left px-4 py-2 text-sm transition-colors ${
                      selectedCategory === cat.id
                        ? 'bg-burgundy text-white'
                        : 'bg-champagne/30 text-text-primary hover:bg-champagne/50'
                    }`}
                    data-testid={`filter-cat-${cat.id}`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Region Map Filter */}
            <div>
              <h3 className="text-overline text-text-secondary mb-4">
                {language === 'en' ? 'Filter by Region' : 'Filtrer par Région'}
              </h3>
              <IndiaMap 
                onRegionSelect={handleRegionFilter} 
                selectedRegion={selectedRegion} 
              />
            </div>
          </aside>

          {/* Products Grid */}
          <main className="lg:col-span-3">
            {loading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="aspect-[3/4] bg-champagne/30 mb-4" />
                    <div className="h-4 bg-champagne/30 w-3/4 mb-2" />
                    <div className="h-4 bg-champagne/30 w-1/2" />
                  </div>
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-16">
                <p className="text-text-secondary">
                  {language === 'en' ? 'No products found matching your criteria.' : 'Aucun produit trouvé correspondant à vos critères.'}
                </p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product) => (
                  <Link
                    key={product.id}
                    to={`/product/${product.id}`}
                    className="group product-card"
                    data-testid={`product-card-${product.id}`}
                  >
                    <div className="relative overflow-hidden aspect-[3/4] mb-4">
                      <img
                        src={product.image}
                        alt={getName(product)}
                        className="product-image absolute inset-0 w-full h-full object-cover"
                      />
                      {!product.in_stock && (
                        <div className="absolute top-4 left-4 bg-burgundy text-white text-xs px-2 py-1 uppercase tracking-wider">
                          {language === 'en' ? 'Made to Order' : 'Sur Commande'}
                        </div>
                      )}
                    </div>
                    <div className="flex items-start gap-1 text-xs text-emerald mb-1">
                      <MapPin className="w-3 h-3 flex-shrink-0 mt-0.5" />
                      <span>{product.region}</span>
                    </div>
                    <h3 className="font-heading text-lg text-text-primary mb-1 group-hover:text-burgundy transition-colors">
                      {getName(product)}
                    </h3>
                    <p className="text-burgundy font-medium">
                      €{product.price.toLocaleString()}
                    </p>
                  </Link>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>

      {/* DDP Notice */}
      <section className="py-6 px-6 bg-champagne/30 border-t border-champagne">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-text-secondary">
            {t('ddp_notice')}
          </p>
        </div>
      </section>
    </div>
  );
};
