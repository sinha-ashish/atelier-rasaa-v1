import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Checkbox } from '../components/ui/checkbox';
import { toast } from 'sonner';

const LOGO_URL = 'https://customer-assets.emergentagent.com/job_82e6879b-f5ad-4726-b206-ff194ce09f72/artifacts/okpw6poy_RASA%20LOGO.png';

export const LoginPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    company: '',
    is_b2b: false,
  });

  const { login, register, loginWithGoogle } = useAuth();
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  
  const from = location.state?.from?.pathname || '/';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isLogin) {
        await login(formData.email, formData.password);
        toast.success(language === 'en' ? 'Welcome back!' : 'Bon retour!');
      } else {
        await register(formData);
        toast.success(language === 'en' ? 'Account created!' : 'Compte créé!');
      }
      navigate(from, { replace: true });
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = () => {
    loginWithGoogle();
  };

  return (
    <div className="min-h-screen pt-24 flex items-center justify-center px-6 bg-champagne-light/20" data-testid="login-page">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3">
            <img 
              src={LOGO_URL} 
              alt="RASAA Atelier" 
              className="h-16 w-16 rounded-full object-cover"
            />
          </Link>
        </div>

        {/* Card */}
        <div className="bg-white border border-champagne/50 p-8">
          <div className="text-center mb-8">
            <h1 className="font-heading text-2xl tracking-tight text-text-primary mb-2">
              {isLogin ? t('auth_login_title') : t('auth_register_title')}
            </h1>
            <p className="text-text-secondary text-sm">
              {isLogin ? t('auth_login_subtitle') : t('auth_register_subtitle')}
            </p>
          </div>

          {/* Google Login */}
          <button
            onClick={handleGoogleLogin}
            className="w-full flex items-center justify-center gap-3 border border-champagne py-3 px-4 hover:bg-champagne/10 transition-colors mb-6"
            data-testid="google-login-btn"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            <span className="text-sm">{t('auth_google')}</span>
          </button>

          {/* Divider */}
          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-champagne"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-4 text-text-secondary">{t('auth_or')}</span>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <Input
                placeholder={t('auth_name')}
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required={!isLogin}
                data-testid="auth-name-input"
              />
            )}

            <Input
              type="email"
              placeholder={t('auth_email')}
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
              data-testid="auth-email-input"
            />

            <Input
              type="password"
              placeholder={t('auth_password')}
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
              data-testid="auth-password-input"
            />

            {!isLogin && (
              <>
                <Input
                  placeholder={t('auth_company')}
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  data-testid="auth-company-input"
                />

                <div className="flex items-center gap-3">
                  <Checkbox
                    id="is_b2b"
                    checked={formData.is_b2b}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_b2b: checked })}
                    data-testid="auth-b2b-checkbox"
                  />
                  <label htmlFor="is_b2b" className="text-sm text-text-secondary cursor-pointer">
                    {language === 'en' ? 'Apply for B2B Partner Access' : 'Demander l\'accès Partenaire B2B'}
                  </label>
                </div>
              </>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-burgundy hover:bg-burgundy-hover text-white"
              data-testid="auth-submit-btn"
            >
              {loading ? '...' : (isLogin ? t('auth_login_btn') : t('auth_register_btn'))}
            </Button>
          </form>

          {/* Toggle */}
          <div className="mt-6 text-center text-sm text-text-secondary">
            {isLogin ? t('auth_no_account') : t('auth_has_account')}{' '}
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-burgundy hover:underline"
              data-testid="auth-toggle-btn"
            >
              {isLogin ? t('auth_register_btn') : t('auth_login_btn')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
