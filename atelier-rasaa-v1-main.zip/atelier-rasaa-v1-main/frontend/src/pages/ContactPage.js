import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Button } from '../components/ui/button';
import { MapPin, Mail, Phone } from 'lucide-react';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export const ContactPage = () => {
  const { t, language } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch(`${API}/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        toast.success(t('contact_success'));
        setFormData({ name: '', email: '', subject: '', message: '' });
      } else {
        throw new Error('Failed to send');
      }
    } catch (error) {
      toast.error('Failed to send message');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-transition pt-24 min-h-screen" data-testid="contact-page">
      {/* Header */}
      <section className="py-12 lg:py-20 px-6 lg:px-12 bg-champagne-light/30">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-overline text-burgundy mb-4">
            {language === 'en' ? 'Get in Touch' : 'Contactez-Nous'}
          </p>
          <h1 className="font-heading text-4xl lg:text-5xl tracking-tight text-text-primary mb-4">
            {t('contact_title')}
          </h1>
          <p className="text-text-secondary max-w-2xl mx-auto">
            {t('contact_subtitle')}
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Info */}
          <div>
            <h2 className="font-heading text-2xl tracking-tight text-text-primary mb-8">
              {language === 'en' ? 'Our Offices' : 'Nos Bureaux'}
            </h2>

            <div className="space-y-8">
              {/* Paris */}
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-burgundy/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-burgundy" />
                </div>
                <div>
                  <h3 className="font-medium text-text-primary mb-1">Paris, France</h3>
                  <p className="text-text-secondary text-sm">
                    {language === 'en' ? 'European Headquarters' : 'Siège Européen'}
                  </p>
                  <p className="text-text-secondary text-sm mt-2">
                    12 Rue de la Paix<br />
                    75002 Paris
                  </p>
                </div>
              </div>

              {/* Jaipur */}
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-emerald/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-emerald" />
                </div>
                <div>
                  <h3 className="font-medium text-text-primary mb-1">Jaipur, India</h3>
                  <p className="text-text-secondary text-sm">
                    {language === 'en' ? 'Artisan Coordination Center' : 'Centre de Coordination Artisanal'}
                  </p>
                  <p className="text-text-secondary text-sm mt-2">
                    C-Scheme, Ashok Nagar<br />
                    Jaipur, Rajasthan 302001
                  </p>
                </div>
              </div>

              {/* Contact Details */}
              <div className="pt-8 border-t border-champagne space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-burgundy" />
                  <a href="mailto:contact@rasaa-atelier.com" className="text-text-secondary hover:text-burgundy">
                    contact@rasaa-atelier.com
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-burgundy" />
                  <span className="text-text-secondary">+33 1 42 00 00 00</span>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white border border-champagne/50 p-8">
            <h2 className="font-heading text-2xl tracking-tight text-text-primary mb-6">
              {language === 'en' ? 'Send us a Message' : 'Envoyez-nous un Message'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-5">
              <Input
                placeholder={t('contact_name')}
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                data-testid="contact-form-name"
              />
              <Input
                type="email"
                placeholder={t('contact_email')}
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                data-testid="contact-form-email"
              />
              <Input
                placeholder={t('contact_subject')}
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                required
                data-testid="contact-form-subject"
              />
              <Textarea
                placeholder={t('contact_message')}
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                rows={5}
                required
                data-testid="contact-form-message"
              />
              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-burgundy hover:bg-burgundy-hover text-white"
                data-testid="contact-form-submit"
              >
                {loading ? '...' : t('contact_send')}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
