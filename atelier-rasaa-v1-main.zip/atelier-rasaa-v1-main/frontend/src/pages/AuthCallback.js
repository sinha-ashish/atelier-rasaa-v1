import React, { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export const AuthCallback = () => {
  const { exchangeSession } = useAuth();
  const navigate = useNavigate();
  const hasProcessed = useRef(false);

  useEffect(() => {
    // Use ref to prevent double processing in StrictMode
    if (hasProcessed.current) return;
    hasProcessed.current = true;

    const processCallback = async () => {
      try {
        // Get session_id from URL fragment
        const hash = window.location.hash;
        const params = new URLSearchParams(hash.replace('#', ''));
        const sessionId = params.get('session_id');

        if (!sessionId) {
          console.error('No session_id in callback');
          navigate('/login', { replace: true });
          return;
        }

        // Exchange session_id for user data
        const data = await exchangeSession(sessionId);
        
        // Navigate to home with user data
        navigate('/', { 
          replace: true, 
          state: { user: data.user } 
        });
      } catch (error) {
        console.error('Auth callback error:', error);
        navigate('/login', { replace: true });
      }
    };

    processCallback();
  }, [exchangeSession, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-champagne-light/20">
      <div className="text-center">
        <div className="w-12 h-12 border-2 border-burgundy border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-text-secondary">Authenticating...</p>
      </div>
    </div>
  );
};
