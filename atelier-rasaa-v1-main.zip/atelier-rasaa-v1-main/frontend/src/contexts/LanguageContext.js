import React, { createContext, useContext, useState } from 'react';

const LanguageContext = createContext(null);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

const translations = {
  en: {
    // Navigation
    nav_home: 'Home',
    nav_boutique: 'The Edit',
    nav_showroom: 'Sourcing Showroom',
    nav_map: 'Heritage Map',
    nav_about: 'About',
    nav_contact: 'Contact',
    nav_login: 'Sign In',
    nav_logout: 'Sign Out',
    nav_partner_login: 'Partner Login',
    
    // Hero
    hero_overline: 'Indo-French High-Savoir Faire',
    hero_title: 'The Cultural Bridge',
    hero_subtitle: 'Where centuries of Indian artistry meets French elegance. A new savoir-faire.',
    hero_cta_explore: 'Explore The Edit',
    hero_cta_b2b: 'Request Wholesale Access',
    
    // Manifesto
    manifesto_title: 'The RASAA Manifesto',
    manifesto_line1: 'Heritage over Haste.',
    manifesto_line2: 'Artistry over Automation.',
    manifesto_line3: 'A New Savoir-Faire.',
    
    // Categories
    cat_jewelry: 'Jewelry',
    cat_apparel: 'Apparel',
    cat_carpets: 'Hand-knotted Carpets',
    cat_gemstones: 'Gemstones & Silver',
    cat_textiles: 'Textile Archive',
    
    // Product
    product_provenance: 'Provenance',
    product_artisan: 'Artisan Cluster',
    product_region: 'Region of Origin',
    product_contact_cta: 'Inquire About This Piece',
    product_quote_cta: 'Request Quote',
    
    // B2B
    b2b_title: 'Sourcing Showroom',
    b2b_subtitle: 'Premium materials for discerning maisons',
    b2b_access_title: 'Professional Partners Only',
    b2b_access_desc: 'Access our complete material library with pricing, certifications, and direct ordering.',
    b2b_request_access: 'Request Wholesale Access',
    b2b_login: 'Partner Login',
    
    // Map
    map_title: 'Pan-India Heritage Map',
    map_subtitle: 'Click a region to discover its artisan traditions',
    map_filter_all: 'All Regions',
    
    // Footer
    footer_tagline: 'Artistry over Automation',
    footer_traceability: 'The Traceability Ledger',
    footer_sustainability: 'Every piece tells a story. Every purchase supports an artisan.',
    footer_links_company: 'Company',
    footer_links_support: 'Support',
    footer_links_legal: 'Legal',
    
    // Auth
    auth_login_title: 'Welcome Back',
    auth_login_subtitle: 'Sign in to your account',
    auth_register_title: 'Join RASAA',
    auth_register_subtitle: 'Create your account',
    auth_email: 'Email',
    auth_password: 'Password',
    auth_name: 'Full Name',
    auth_company: 'Company (for B2B)',
    auth_login_btn: 'Sign In',
    auth_register_btn: 'Create Account',
    auth_google: 'Continue with Google',
    auth_or: 'or',
    auth_no_account: "Don't have an account?",
    auth_has_account: 'Already have an account?',
    
    // Contact
    contact_title: 'Get in Touch',
    contact_subtitle: 'We would love to hear from you',
    contact_name: 'Your Name',
    contact_email: 'Email Address',
    contact_subject: 'Subject',
    contact_message: 'Message',
    contact_send: 'Send Message',
    contact_success: 'Message sent successfully!',
    
    // Quote
    quote_title: 'Request a Quote',
    quote_quantity: 'Quantity Required',
    quote_specs: 'Specifications',
    quote_phone: 'Phone Number',
    quote_submit: 'Submit Request',
    quote_success: 'Quote request submitted!',
    
    // Wholesale
    wholesale_title: 'Request Wholesale Access',
    wholesale_company: 'Company Name',
    wholesale_contact: 'Contact Person',
    wholesale_phone: 'Phone',
    wholesale_business: 'Business Type',
    wholesale_message: 'Tell us about your needs',
    wholesale_submit: 'Submit Request',
    wholesale_success: 'Request submitted! We will contact you shortly.',
    
    // DDP Notice
    ddp_notice: 'All prices include delivery to France (DDP). VAT and duties calculated at checkout.',
  },
  fr: {
    // Navigation
    nav_home: 'Accueil',
    nav_boutique: 'La Sélection',
    nav_showroom: 'Showroom Sourcing',
    nav_map: 'Carte Patrimoine',
    nav_about: 'À Propos',
    nav_contact: 'Contact',
    nav_login: 'Connexion',
    nav_logout: 'Déconnexion',
    nav_partner_login: 'Espace Partenaire',
    
    // Hero
    hero_overline: 'Haute-Savoir Faire Indo-Français',
    hero_title: 'Le Pont Culturel',
    hero_subtitle: 'Où des siècles d\'artisanat indien rencontrent l\'élégance française. Un nouveau savoir-faire.',
    hero_cta_explore: 'Découvrir La Sélection',
    hero_cta_b2b: 'Accès Grossiste',
    
    // Manifesto
    manifesto_title: 'Le Manifeste RASAA',
    manifesto_line1: 'L\'Héritage avant la Hâte.',
    manifesto_line2: 'L\'Artisanat avant l\'Automatisation.',
    manifesto_line3: 'Un Nouveau Savoir-Faire.',
    
    // Categories
    cat_jewelry: 'Joaillerie',
    cat_apparel: 'Vêtements',
    cat_carpets: 'Tapis Noués Main',
    cat_gemstones: 'Pierres & Argent',
    cat_textiles: 'Archives Textiles',
    
    // Product
    product_provenance: 'Provenance',
    product_artisan: 'Cluster Artisanal',
    product_region: 'Région d\'Origine',
    product_contact_cta: 'Se Renseigner sur Cette Pièce',
    product_quote_cta: 'Demander un Devis',
    
    // B2B
    b2b_title: 'Showroom Sourcing',
    b2b_subtitle: 'Matériaux premium pour maisons exigeantes',
    b2b_access_title: 'Réservé aux Partenaires Professionnels',
    b2b_access_desc: 'Accédez à notre bibliothèque complète avec tarifs, certifications et commandes directes.',
    b2b_request_access: 'Demander l\'Accès Grossiste',
    b2b_login: 'Connexion Partenaire',
    
    // Map
    map_title: 'Carte du Patrimoine Pan-Indien',
    map_subtitle: 'Cliquez sur une région pour découvrir ses traditions artisanales',
    map_filter_all: 'Toutes les Régions',
    
    // Footer
    footer_tagline: 'L\'Artisanat avant l\'Automatisation',
    footer_traceability: 'Le Registre de Traçabilité',
    footer_sustainability: 'Chaque pièce raconte une histoire. Chaque achat soutient un artisan.',
    footer_links_company: 'Entreprise',
    footer_links_support: 'Support',
    footer_links_legal: 'Mentions Légales',
    
    // Auth
    auth_login_title: 'Bon Retour',
    auth_login_subtitle: 'Connectez-vous à votre compte',
    auth_register_title: 'Rejoignez RASAA',
    auth_register_subtitle: 'Créez votre compte',
    auth_email: 'Email',
    auth_password: 'Mot de passe',
    auth_name: 'Nom Complet',
    auth_company: 'Entreprise (pour B2B)',
    auth_login_btn: 'Se Connecter',
    auth_register_btn: 'Créer un Compte',
    auth_google: 'Continuer avec Google',
    auth_or: 'ou',
    auth_no_account: "Pas encore de compte?",
    auth_has_account: 'Déjà un compte?',
    
    // Contact
    contact_title: 'Contactez-Nous',
    contact_subtitle: 'Nous serions ravis de vous entendre',
    contact_name: 'Votre Nom',
    contact_email: 'Adresse Email',
    contact_subject: 'Sujet',
    contact_message: 'Message',
    contact_send: 'Envoyer',
    contact_success: 'Message envoyé avec succès!',
    
    // Quote
    quote_title: 'Demander un Devis',
    quote_quantity: 'Quantité Requise',
    quote_specs: 'Spécifications',
    quote_phone: 'Numéro de Téléphone',
    quote_submit: 'Soumettre la Demande',
    quote_success: 'Demande de devis soumise!',
    
    // Wholesale
    wholesale_title: 'Demander l\'Accès Grossiste',
    wholesale_company: 'Nom de l\'Entreprise',
    wholesale_contact: 'Personne de Contact',
    wholesale_phone: 'Téléphone',
    wholesale_business: 'Type d\'Activité',
    wholesale_message: 'Parlez-nous de vos besoins',
    wholesale_submit: 'Soumettre',
    wholesale_success: 'Demande soumise! Nous vous contacterons bientôt.',
    
    // DDP Notice
    ddp_notice: 'Tous les prix incluent la livraison en France (DDP). TVA et droits calculés à la commande.',
  }
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState('en');

  const t = (key) => {
    return translations[language][key] || key;
  };

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'fr' : 'en');
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};
