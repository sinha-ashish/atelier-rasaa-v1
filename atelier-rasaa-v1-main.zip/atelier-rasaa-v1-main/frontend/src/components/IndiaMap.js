import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';

// Simplified India map with key craft regions
const REGIONS = [
  { id: 'kashmir', name: 'Kashmir', nameFr: 'Cachemire', x: 180, y: 45, crafts: ['Pashmina', 'Silk Carpets', 'Sapphires'] },
  { id: 'rajasthan', name: 'Rajasthan', nameFr: 'Rajasthan', x: 120, y: 140, crafts: ['Block Prints', 'Kundan Jewelry', 'Dhurrie Carpets'] },
  { id: 'gujarat', name: 'Gujarat', nameFr: 'Gujarat', x: 85, y: 180, crafts: ['Lab-Grown Diamonds', 'Bandhani Textiles', 'Patola Silk'] },
  { id: 'madhya_pradesh', name: 'Madhya Pradesh', nameFr: 'Madhya Pradesh', x: 175, y: 180, crafts: ['Chanderi Silk', 'Maheshwari Fabric'] },
  { id: 'uttar_pradesh', name: 'Uttar Pradesh', nameFr: 'Uttar Pradesh', x: 210, y: 130, crafts: ['Banarasi Silk', 'Chikankari', 'Brassware'] },
  { id: 'west_bengal', name: 'West Bengal', nameFr: 'Bengale-Occidental', x: 285, y: 175, crafts: ['Baluchari Silk', 'Dokra Metalwork', 'Terracotta'] },
  { id: 'odisha', name: 'Odisha', nameFr: 'Odisha', x: 260, y: 210, crafts: ['Pattachitra', 'Sambalpuri Ikat', 'Silver Filigree'] },
  { id: 'tamil_nadu', name: 'Tamil Nadu', nameFr: 'Tamil Nadu', x: 195, y: 310, crafts: ['Temple Jewelry', 'Kanchipuram Silk', 'Bronze Sculptures'] },
];

export const IndiaMap = ({ onRegionSelect, selectedRegion }) => {
  const [hoveredRegion, setHoveredRegion] = useState(null);
  const { language, t } = useLanguage();

  const getRegionName = (region) => {
    return language === 'fr' ? region.nameFr : region.name;
  };

  return (
    <div className="relative" data-testid="india-map">
      {/* Map Container */}
      <div className="relative bg-champagne-light/30 rounded-lg p-8 border border-champagne/30">
        <svg
          viewBox="0 0 350 400"
          className="w-full max-w-md mx-auto"
          style={{ filter: 'drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1))' }}
        >
          {/* Simplified India outline */}
          <path
            d="M180 30 L220 50 L250 45 L280 70 L300 100 L310 140 L300 180 L290 200 L280 220 L260 250 L240 280 L220 310 L200 340 L180 360 L160 340 L140 310 L120 280 L100 250 L80 220 L70 190 L60 160 L70 130 L90 100 L120 70 L150 45 Z"
            className="fill-champagne stroke-burgundy"
            strokeWidth="2"
          />
          
          {/* Region dots */}
          {REGIONS.map((region) => (
            <g key={region.id}>
              <circle
                cx={region.x}
                cy={region.y}
                r={selectedRegion === region.id ? 14 : hoveredRegion === region.id ? 12 : 8}
                className={`cursor-pointer transition-all duration-300 ${
                  selectedRegion === region.id
                    ? 'fill-burgundy stroke-champagne'
                    : hoveredRegion === region.id
                    ? 'fill-burgundy-light stroke-champagne'
                    : 'fill-emerald stroke-champagne/50'
                }`}
                strokeWidth={selectedRegion === region.id ? 3 : 2}
                onMouseEnter={() => setHoveredRegion(region.id)}
                onMouseLeave={() => setHoveredRegion(null)}
                onClick={() => onRegionSelect(region.id === selectedRegion ? null : region.id)}
                data-testid={`map-region-${region.id}`}
              />
              {(hoveredRegion === region.id || selectedRegion === region.id) && (
                <text
                  x={region.x}
                  y={region.y - 20}
                  textAnchor="middle"
                  className="fill-burgundy font-body text-xs font-medium"
                >
                  {getRegionName(region)}
                </text>
              )}
            </g>
          ))}
        </svg>

        {/* Tooltip */}
        {hoveredRegion && (
          <div className="absolute top-4 right-4 bg-white p-4 rounded shadow-lg border border-champagne/30 max-w-xs">
            <h4 className="font-heading text-lg text-burgundy mb-2">
              {getRegionName(REGIONS.find(r => r.id === hoveredRegion))}
            </h4>
            <div className="flex flex-wrap gap-1">
              {REGIONS.find(r => r.id === hoveredRegion)?.crafts.map((craft, i) => (
                <span key={i} className="text-xs bg-champagne/50 text-burgundy px-2 py-0.5 rounded">
                  {craft}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Region Buttons */}
      <div className="mt-6 flex flex-wrap gap-2 justify-center">
        <button
          onClick={() => onRegionSelect(null)}
          className={`text-xs uppercase tracking-wider px-3 py-1.5 border transition-colors ${
            !selectedRegion
              ? 'bg-burgundy text-white border-burgundy'
              : 'bg-white text-burgundy border-burgundy/30 hover:border-burgundy'
          }`}
          data-testid="map-filter-all"
        >
          {t('map_filter_all')}
        </button>
        {REGIONS.map((region) => (
          <button
            key={region.id}
            onClick={() => onRegionSelect(region.id === selectedRegion ? null : region.id)}
            className={`text-xs uppercase tracking-wider px-3 py-1.5 border transition-colors ${
              selectedRegion === region.id
                ? 'bg-burgundy text-white border-burgundy'
                : 'bg-white text-burgundy border-burgundy/30 hover:border-burgundy'
            }`}
            data-testid={`map-filter-${region.id}`}
          >
            {getRegionName(region)}
          </button>
        ))}
      </div>
    </div>
  );
};

export const REGION_DATA = REGIONS;
