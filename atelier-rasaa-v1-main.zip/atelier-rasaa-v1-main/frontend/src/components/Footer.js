import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Flower2, Instagram, Linkedin, Mail } from 'lucide-react';

const LOGO_URL = 'https://customer-assets.emergentagent.com/job_82e6879b-f5ad-4726-b206-ff194ce09f72/artifacts/okpw6poy_RASA%20LOGO.png';

export const Footer = () => {
  const { t, language } = useLanguage();

  return (
    <footer className="bg-dark-section text-white" data-testid="main-footer">
      {/* Traceability Ledger Section */}
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-overline text-champagne mb-4">{t('footer_traceability')}</p>
              <h2 className="font-heading text-3xl lg:text-4xl tracking-tight mb-6">
                {t('footer_tagline')}
              </h2>
              <p className="text-white/70 leading-relaxed max-w-lg">
                {t('footer_sustainability')}
              </p>
            </div>
            <div className="flex justify-center lg:justify-end">
              <div className="relative">
                <div className="w-48 h-48 rounded-full border border-champagne/30 flex items-center justify-center">
                  <div className="w-36 h-36 rounded-full border border-champagne/50 flex items-center justify-center">
                    <Flower2 className="w-16 h-16 text-champagne" strokeWidth={1} />
                  </div>
                </div>
                <div className="absolute -top-2 -right-2 w-4 h-4 bg-emerald rounded-full" />
                <div className="absolute -bottom-2 -left-2 w-3 h-3 bg-champagne rounded-full" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12 lg:py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center gap-3 mb-6">
              <img 
                src={LOGO_URL} 
                alt="RASAA Atelier" 
                className="h-10 w-10 rounded-full object-cover"
              />
              <span className="font-heading text-lg">
                RASAA <span className="font-light">Atelier</span>
              </span>
            </Link>
            <p className="text-white/60 text-sm leading-relaxed">
              {language === 'en' 
                ? 'The Cultural Bridge between Indian artisanry and French elegance.'
                : 'Le Pont Culturel entre l\'artisanat indien et l\'élégance française.'}
            </p>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="text-overline text-champagne mb-4">{t('footer_links_company')}</h4>
            <ul className="space-y-3">
              <li>
                <Link to="/about" className="text-white/70 hover:text-white text-sm transition-colors">
                  {language === 'en' ? 'Our Story' : 'Notre Histoire'}
                </Link>
              </li>
              <li>
                <Link to="/boutique" className="text-white/70 hover:text-white text-sm transition-colors">
                  {t('nav_boutique')}
                </Link>
              </li>
              <li>
                <Link to="/showroom" className="text-white/70 hover:text-white text-sm transition-colors">
                  {t('nav_showroom')}
                </Link>
              </li>
              <li>
                <Link to="/map" className="text-white/70 hover:text-white text-sm transition-colors">
                  {t('nav_map')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-overline text-champagne mb-4">{t('footer_links_support')}</h4>
            <ul className="space-y-3">
              <li>
                <Link to="/contact" className="text-white/70 hover:text-white text-sm transition-colors">
                  {t('nav_contact')}
                </Link>
              </li>
              <li>
                <span className="text-white/70 text-sm">
                  {language === 'en' ? 'Shipping & Returns' : 'Livraison & Retours'}
                </span>
              </li>
              <li>
                <span className="text-white/70 text-sm">
                  {language === 'en' ? 'Care Guide' : 'Guide d\'Entretien'}
                </span>
              </li>
              <li>
                <span className="text-white/70 text-sm">FAQ</span>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-overline text-champagne mb-4">
              {language === 'en' ? 'Connect' : 'Rejoignez-nous'}
            </h4>
            <div className="flex gap-4 mb-6">
              <a href="#" className="text-white/70 hover:text-champagne transition-colors" aria-label="Instagram">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-white/70 hover:text-champagne transition-colors" aria-label="LinkedIn">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="mailto:contact@rasaa-atelier.com" className="text-white/70 hover:text-champagne transition-colors" aria-label="Email">
                <Mail className="w-5 h-5" />
              </a>
            </div>
            <p className="text-white/50 text-xs">
              Paris, France<br />
              Jaipur, India
            </p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/40 text-xs">
            © {new Date().getFullYear()} RASAA Atelier. {language === 'en' ? 'All rights reserved.' : 'Tous droits réservés.'}
          </p>
          <div className="flex gap-6">
            <span className="text-white/40 text-xs hover:text-white/60 cursor-pointer">
              {language === 'en' ? 'Privacy Policy' : 'Politique de Confidentialité'}
            </span>
            <span className="text-white/40 text-xs hover:text-white/60 cursor-pointer">
              {language === 'en' ? 'Terms of Service' : 'Conditions d\'Utilisation'}
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
