import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { Menu, X, Globe, User, ChevronDown } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

const LOGO_URL = 'https://customer-assets.emergentagent.com/job_82e6879b-f5ad-4726-b206-ff194ce09f72/artifacts/okpw6poy_RASA%20LOGO.png';

export const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const { language, toggleLanguage, t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  
  const isHome = location.pathname === '/';
  const isTransparent = isHome;

  const navLinks = [
    { href: '/boutique', label: t('nav_boutique') },
    { href: '/showroom', label: t('nav_showroom') },
    { href: '/map', label: t('nav_map') },
    { href: '/contact', label: t('nav_contact') },
  ];

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isTransparent 
          ? 'bg-transparent' 
          : 'nav-glass'
      }`}
      data-testid="main-navbar"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3" data-testid="navbar-logo">
            <img 
              src={LOGO_URL} 
              alt="RASAA Atelier" 
              className="h-12 w-12 rounded-full object-cover"
            />
            <span className={`font-heading text-xl tracking-tight ${isTransparent ? 'text-white' : 'text-burgundy'}`}>
              RASAA <span className="font-light">Atelier</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={`text-overline transition-colors hover:text-burgundy ${
                  isTransparent ? 'text-white/90 hover:text-champagne' : 'text-text-secondary'
                } ${location.pathname === link.href ? (isTransparent ? 'text-champagne' : 'text-burgundy') : ''}`}
                data-testid={`nav-link-${link.href.slice(1)}`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Right Side Actions */}
          <div className="hidden lg:flex items-center gap-4">
            {/* Language Toggle */}
            <button
              onClick={toggleLanguage}
              className={`flex items-center gap-1 text-sm uppercase tracking-wider transition-colors ${
                isTransparent ? 'text-white/90 hover:text-champagne' : 'text-text-secondary hover:text-burgundy'
              }`}
              data-testid="language-toggle"
            >
              <Globe className="w-4 h-4" />
              {language}
            </button>

            {/* Auth */}
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger 
                  className={`flex items-center gap-2 text-sm ${
                    isTransparent ? 'text-white' : 'text-text-primary'
                  }`}
                  data-testid="user-menu-trigger"
                >
                  {user?.picture ? (
                    <img src={user.picture} alt="" className="w-8 h-8 rounded-full" />
                  ) : (
                    <User className="w-5 h-5" />
                  )}
                  <span className="hidden xl:inline">{user?.name?.split(' ')[0]}</span>
                  <ChevronDown className="w-4 h-4" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={handleLogout} data-testid="logout-btn">
                    {t('nav_logout')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link
                to="/login"
                className={`btn-luxury text-xs py-2 px-4 ${
                  isTransparent ? 'text-white border-white/50 hover:bg-white hover:text-burgundy' : ''
                }`}
                data-testid="login-nav-btn"
              >
                {t('nav_login')}
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`lg:hidden p-2 ${isTransparent ? 'text-white' : 'text-burgundy'}`}
            data-testid="mobile-menu-toggle"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-museum-white border-t border-border-subtle" data-testid="mobile-menu">
          <div className="px-6 py-4 space-y-4">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className="block text-overline text-text-secondary hover:text-burgundy py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <hr className="border-border-subtle" />
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-2 text-sm text-text-secondary py-2"
            >
              <Globe className="w-4 h-4" />
              {language === 'en' ? 'Français' : 'English'}
            </button>
            {isAuthenticated ? (
              <button
                onClick={handleLogout}
                className="text-overline text-burgundy py-2"
              >
                {t('nav_logout')}
              </button>
            ) : (
              <Link
                to="/login"
                className="block text-overline text-burgundy py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                {t('nav_login')}
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};
