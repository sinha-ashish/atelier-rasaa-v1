import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { ArrowRight, Play } from 'lucide-react';

const HERO_IMAGE = 'https://images.unsplash.com/photo-1773847099342-33b0381cbe0d?auto=format&fit=crop&q=80';

export const Hero = () => {
  const { t } = useLanguage();

  return (
    <section className="hero-video-container" data-testid="hero-section">
      {/* Background Image with Animation */}
      <img
        src={HERO_IMAGE}
        alt="Artisan craftsmanship"
        className="hero-video-bg"
      />

      {/* Content Overlay */}
      <div className="hero-content h-full flex flex-col justify-center items-center text-center px-6">
        {/* Overline */}
        <p className="text-overline text-champagne mb-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          {t('hero_overline')}
        </p>

        {/* Main Title */}
        <h1 
          className="font-heading text-4xl sm:text-5xl lg:text-7xl text-white tracking-tighter mb-6 animate-fade-in"
          style={{ animationDelay: '0.4s' }}
        >
          {t('hero_title')}
        </h1>

        {/* Subtitle */}
        <p 
          className="text-white/80 text-base lg:text-lg max-w-2xl mb-10 leading-relaxed animate-fade-in"
          style={{ animationDelay: '0.6s' }}
        >
          {t('hero_subtitle')}
        </p>

        {/* CTAs */}
        <div 
          className="flex flex-col sm:flex-row gap-4 animate-fade-in"
          style={{ animationDelay: '0.8s' }}
        >
          <Link
            to="/boutique"
            className="btn-luxury btn-luxury-filled flex items-center gap-2 justify-center"
            data-testid="hero-explore-btn"
          >
            {t('hero_cta_explore')}
            <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            to="/showroom"
            className="btn-luxury text-white border-white/50 hover:bg-white hover:text-burgundy flex items-center gap-2 justify-center"
            data-testid="hero-b2b-btn"
          >
            {t('hero_cta_b2b')}
          </Link>
        </div>
      </div>

      {/* Manifesto Scroll */}
      <div className="absolute bottom-0 left-0 right-0 h-24 overflow-hidden bg-gradient-to-t from-black/60 to-transparent">
        <div className="flex items-center justify-center h-full">
          <div className="flex gap-8 lg:gap-16 text-white/60 text-overline whitespace-nowrap">
            <span>{t('manifesto_line1')}</span>
            <span className="text-champagne">•</span>
            <span>{t('manifesto_line2')}</span>
            <span className="text-champagne">•</span>
            <span>{t('manifesto_line3')}</span>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-32 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <div className="w-px h-12 bg-gradient-to-b from-transparent via-white/50 to-white/20" />
      </div>
    </section>
  );
};
